package com.example.etalaseapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class Detail : AppCompatActivity() {
    companion object {
        const val EX_NAME = "nama"
        const val EX_DETAIL = "detail"
        const val EX_IMAGE = "gambar"
        const val EX_WEIGHT = "berat"
        const val EX_FEE = "harga"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        supportActionBar?.title = "Detail Barang"

        val tvnama: TextView = findViewById(R.id.i_name)
        val tvDetail: TextView = findViewById(R.id.i_detail)
        var tvimg: ImageView = findViewById(R.id.i_image)
        var tvBerat: TextView = findViewById(R.id.i_weight)
        var tvFee: TextView = findViewById(R.id.i_fee)

        var tberat = intent.getIntExtra(EX_WEIGHT, 0).toString()
        var tharga = intent.getIntExtra(EX_FEE, 0).toString()

        var berat = " $tberat Gram "
        var harga = "Rp. $tharga "

        tvnama.text = intent.getStringExtra(EX_NAME)
        tvDetail.text = intent.getStringExtra(EX_DETAIL)
        tvimg.setImageResource(intent.getIntExtra(EX_IMAGE, 0))
        tvBerat.text = berat
        tvFee.text = harga
    }

}