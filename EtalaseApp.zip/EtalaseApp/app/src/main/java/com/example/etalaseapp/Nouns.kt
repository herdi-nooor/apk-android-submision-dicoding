package com.example.etalaseapp


data class Nouns (
    var name: String = "",
    var detail: String = "",
    var image: Int = 0,
    var berat: Int = 0,
    var harga: Int = 0
)