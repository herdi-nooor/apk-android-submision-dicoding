package com.example.etalaseapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Listq : AppCompatActivity() {
    private lateinit var rvNouns: RecyclerView
    private val list: ArrayList<Nouns> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_listq)

        rvNouns = findViewById(R.id.rv)
        rvNouns.setHasFixedSize(true)

        supportActionBar?.title = "Daftar Barang"

        list.addAll(NounsData.listData)
        showRecyclerList()
    }

    private fun showRecyclerList() {
        rvNouns.layoutManager = LinearLayoutManager(this)
        val listNounAdapter= ListNounAdapter(list)
        rvNouns.adapter = listNounAdapter

        listNounAdapter.setOnItemClickCallback(object : ListNounAdapter.OnItemClickCallback {
            override fun onItemClicked(data: Nouns) {
                showSelect(data)
            }
        })
    }

    private fun showSelect(noun: Nouns) {
        val moveIntent: Intent = Intent(this@Listq, Detail::class.java)
        moveIntent.putExtra(Detail.EX_IMAGE, noun.image)
        moveIntent.putExtra(Detail.EX_NAME, noun.name)
        moveIntent.putExtra(Detail.EX_DETAIL, noun.detail)
        moveIntent.putExtra(Detail.EX_WEIGHT, noun.berat)
        moveIntent.putExtra(Detail.EX_FEE, noun.harga)

        Toast.makeText(this, "memilih" + noun.name , Toast.LENGTH_SHORT).show()

        startActivity(moveIntent)
    }
}

