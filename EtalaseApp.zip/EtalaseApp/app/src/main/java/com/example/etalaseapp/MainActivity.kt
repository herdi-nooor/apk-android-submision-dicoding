package com.example.etalaseapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.view.View
import android.widget.Button

class MainActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnToList: Button = findViewById(R.id.btolist)
        val btnAbout: Button = findViewById(R.id.btoabout)

        btnToList.setOnClickListener(this)
        btnAbout.setOnClickListener(this)

        supportActionBar?.title = "Apllikasi daftar barang"
    }

    override fun onClick(v: View?){
        when (v?.id) {
            R.id.btolist -> {
                val moveIntent = Intent(this@MainActivity, Listq::class.java)
                startActivity(moveIntent)
            }
            R.id.btoabout -> {
                val moveIntent = Intent(this@MainActivity, About::class.java)
                startActivity(moveIntent)
            }
        }
    }
}