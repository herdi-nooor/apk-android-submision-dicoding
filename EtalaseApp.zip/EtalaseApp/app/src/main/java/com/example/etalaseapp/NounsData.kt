package com.example.etalaseapp

object NounsData {
    private val nounsName = arrayOf(
        "bubuk cabai", "bubuk daun salam", "bubuk jahe", "bubuk ketumbar",
        "bubuk kunyit", "bubuk lada putih", "bubuk lada hitam", "beras merah" ,"beras mathi"
    )

    private val nounsDetails = arrayOf(
        "terbuat dari cabai rawit pilihan, yang di tanam secara organik dengan pengawasan dari petani berpengalaman, diolah secara tradisional dan dikemas secara higienis, tanpa tambahan bahan pengawet, 100% asli tanpa tambahan bahan campuran apapun",
        "terbuat dari daun salam pilihan, yang di tanam  dengan pengawasan dari petani berpengalaman, diolah secara tradisional dan dikemas secara higienis, tanpa tambahan bahan pengawet, 100% asli tanpa tambahan bahan campuran apapun",
        "terbuat dari jahe pilihan, yang di tanam secara organik dengan pengawasan dari petani berpengalaman, diolah secara tradisional dan dikemas secara higienis, tanpa tambahan bahan pengawet, 100% asli tanpa tambahan bahan campuran apapun",
        "terbuat dari biji ketumbar pilihan, yang di tanam secara organik dengan pengawasan dari petani berpengalaman, diolah secara tradisional dan dikemas secara higienis, tanpa tambahan bahan pengawet, 100% asli tanpa tambahan bahan campuran apapun",
        "terbuat dari kunyit pilihan, yang di tanam secara organik dengan pengawasan dari petani berpengalaman, diolah secara tradisional dan dikemas secara higienis, tanpa tambahan bahan pengawet, 100% asli tanpa tambahan bahan campuran apapun",
        "terbuat dari biji lada putih pilihan, yang di tanam secara organik dengan pengawasan dari petani berpengalaman, diolah secara tradisional dan dikemas secara higienis, tanpa tambahan bahan pengawet, 100% asli tanpa tambahan bahan campuran apapun",
        "terbuat dari biji lada hitam pilihan, yang di tanam secara organik dengan pengawasan dari petani berpengalaman, diolah secara tradisional dan dikemas secara higienis, tanpa tambahan bahan pengawet, 100% asli tanpa tambahan bahan campuran apapun",
        "diambil dari beras merah pilihan pilihan, yang di tanam secara organik dengan pengawasan dari petani berpengalaman, diolah dengan tehknologi canggih, dibersihkan, dan dikemas secara higienis.",
        "diambil dari beras mathi pilihan pilihan, yang di tanam secara organik dengan pengawasan dari petani berpengalaman, diolah dengan tehknologi canggih, dibersihkan, dan dikemas secara higienis. di import langsung dari timur tengah"
    )

    private val nounsimages = intArrayOf(
        R.drawable.cabai,
        R.drawable.daun_salam,
        R.drawable.jahe,
        R.drawable.ketumbar,
        R.drawable.kunyit,
        R.drawable.lada,
        R.drawable.lada_hitam,
        R.drawable.beras_merah,
        R.drawable.beras_mathi
    )

    private val nounsberat = intArrayOf(
        20, 25, 12, 12, 25,
        10, 10, 500, 1000
    )

    private val nounsHarga = intArrayOf(
        3500, 1000, 3000, 1500, 1000,
        4000, 3500, 25000, 150000
    )

    val listData: ArrayList<Nouns>
        get() {
            val list = arrayListOf<Nouns>()
            for (position in nounsName.indices){
                val noun = Nouns()
                noun.name = nounsName[position]
                noun.detail = nounsDetails[position]
                noun.image = nounsimages[position]
                noun.berat = nounsberat[position]
                noun.harga = nounsHarga[position]
                list.add(noun)
            }
            return list
        }
}